import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class HangmanApp extends PApplet {




boolean won;
boolean lost;
Person person;
Word word;
Keyboard keyboard;
Button newGameBtn;
PFont txtFont;
SoundFile wonSound;
SoundFile lostSound;


public void setup() { 
  
  newGame();
  wonSound = new SoundFile(this, "you_won.wav");  
  lostSound = new SoundFile(this, "death_sound.wav");
}

public void draw() {
  // keep drawing these to handle clicks, hovers and end of game
  keyboard.display();
  keyboard.hover();
  newGameBtn.display();
  newGameBtn.hover();
  // check to see if we have won or lost
  //checkResult();
}

// start a new game
public void newGame() {
  background(26,83,92);
  person = new Person((width/2), 0);
  person.drawRope();
  word = new Word((width/2), 400);
  word.display();
  keyboard = new Keyboard((width/2), 500);
  keyboard.reset();
  newGameBtn = new Button((width/2), 700);  
  won = false;
  lost = false;
}

// track when a letter button is pressed or new game button is pressed
public void mouseReleased() {
  // check for new game click
  if(newGameBtn.hover) {
    newGame();
  } 
  if(won || lost) {
    return;
  }
  // check for letter click
  for(int i=0; i<keyboard.letters.size(); i++) {
    Letter l = keyboard.letters.get(i);
    if(l.hover && l.active) {
      // choose the letter
      if(word.hasLetter(l.letter)) {
        // add letter to word blanks
        word.addLetter(l.letter);
        // see if the whole word has been filled
        if(word.isComplete()) {
          won = true;
          displayResult(true);          
        }
      } else {
        person.loseLife();
        // see if we don't have any more lives
        if(person.isDead()) {
          lost = true;
          displayResult(false);          
        }
      }
      // deactivate the letter
      l.active = false;
      return;
    }
  }
}

public void displayResult(boolean won) {
  String msg;
  int col;
  if(won) {
    msg = "YOU WON! :)";
    col = 0xffCCFFCC;
    this.wonSound.play();
  } else {
    msg = "YOU LOST :(";
    col = 0xffFF6666;
    this.lostSound.play();
  }
  resetMatrix();
  fill(col);
  textAlign(CENTER, CENTER);
  txtFont = createFont("Helvetica", 18);
  textFont(txtFont);
  text(msg, (width/2)+100, 50);
}
class Button {     

  int x; // center x for word
  int y; // center y for word
  int w;
  int h;
  int tc; // text color
  int bc; // background color
  int hc; // hover border color
  boolean hover;
  String txt;
  int fs; // font size
  PFont txtFont;
  
  Button(int x, int y) {
    this.x = x;
    this.y = y;
    this.w = 180;
    this.h = 30;
    this.tc = 0xffFFFFFF;
    this.bc = 0xff336067;
    this.hc = 0xff4ECCC3;
    this.txt = "NEW GAME";
    this.fs = 14;
  }
  
  public void display() {
    rectMode(CENTER);
    fill(this.bc);
    if(this.hover) {
      stroke(this.hc);
    } else {
      stroke(this.tc);
    }
    rect(this.x, this.y, this.w, this.h, 12, 12, 12, 12);    
    fill(this.tc);
    textAlign(CENTER, CENTER);
    txtFont = createFont("Helvetica", this.fs);
    textFont(txtFont);
    text(this.txt, this.x, this.y); 
  }
  
  // Hover over a button
  public void hover() {    
    hover = mouseX > x-w+fs && mouseX < x+w-fs && mouseY > y-h+fs && mouseY < y+h-fs;
  }

  
}
class Keyboard {

  int x;    
  int y;
  ArrayList<Letter> letters;
  
  Keyboard(int x, int y) {
    this.x = x;
    this.y = y;
    this.create();
  }
  
  public void create() {
    int y = this.y;
    int w = 40;
    int h = 42;
    int space = 10;
    int[] lettersPerRow = { 10, 9, 7 };
    int c = 65;
    this.letters = new ArrayList();
    for(int i = 0; i<lettersPerRow.length; i++) {
      int x = this.x - (((lettersPerRow[i] * w) + ((lettersPerRow[i] - 1) * space)) / 2);      
      for(int j = 0; j < lettersPerRow[i]; j++) {
        letters.add(new Letter(x, y, w, h, PApplet.parseChar(c)));
        x += (w + space);
        c++;
      }
      y += (h + space);
    }    
  }

  // draw letters for keyboard
  public void display() {
    for(int i=0; i<letters.size(); i++) {
      Letter l = letters.get(i);
      l.display();
    }    
  }
  
  // set hover for letters on keyboard
  public void hover() {
    for(int i=0; i<letters.size(); i++) {
      Letter l = letters.get(i);
      l.hover();
    }
  }
  
  // deactivate a letter
  public void deactivate(char l) {
        
  }
  
  public void reset() {
    for(int i=0; i<letters.size(); i++) {
      Letter l = letters.get(i);
      l.reset();
    }    
  }
  
}
class Letter {     

  int x;    
  int y;    
  char letter;
  int w; // width
  int h; // height
  int fs; // font size
  int c; // color
  int ic; // inactive color
  int bc; // hover border color;
  int tc; // text color
  boolean hover; // if we are currently hovering over letter
  boolean active; // if this letter has already been chosen
  PFont txtFont;

  Letter(int x, int y, int w, int h, char letter) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.letter = letter;
    
    this.c = 0xff336067;
    this.ic = 0xff21555E;
    this.bc = 0xff4ECCC3;
    this.tc = 0xffFFFFFF;
    this.fs = 18;
    this.hover = false;
    this.active = true;
    this.hover();
    this.display();
  }

  // Display a letter button
  public void display() {
    if(this.active) {
      if(this.hover) {
        stroke(this.bc);
      } else {
        stroke(this.c);
      }
      fill(this.c);
    } else {
      stroke(this.ic);
      fill(this.ic);
    }        
    rectMode(CENTER);
    rect(this.x, this.y, this.w, this.h);    
    fill(this.tc);
    textAlign(CENTER, CENTER);
    txtFont = createFont("Helvetica", this.fs);
    textFont(txtFont);
    text(this.letter, this.x, this.y);
  }
  
  // Hover over a button
  public void hover() {    
    hover = mouseX > x-w+fs && mouseX < x+w-fs && mouseY > y-h+fs && mouseY < y+h-fs;
  }
  
  public void reset() {
    this.active = true;
  }
}
    
class Person {     

  int lives;
  int x; // center x for person
  int y; // center y for person
  int c; // color
  int rc; // rope color
  int bc; // background color;
  
  Person(int x, int y) {
    this.x = x;
    this.y = y;

    this.lives = 6;
    this.c = 0xffFFFFFF;
    this.rc = 0xff4ECCC3;
  }

  // Draw the hangman's rope
  public void drawRope() {
    fill(this.rc);
    noStroke();
    rectMode(CENTER);
    rect(this.x, this.y+50, 6, 100);
  }

  public void drawBodyPart() {
    fill(this.c);
    noStroke();    

    switch(lives) {
      case 6: // head
        ellipseMode(CENTER);
        ellipse(this.x, this.y+130, 50, 60);
        break;
        
      case 5: // body
        rectMode(CENTER);
        rect(this.x, this.y+200, 6.5f, 100);
        // noose
        fill(this.rc);
        rect(this.x, this.y+162, 12, 6);        
        break;
        
      case 4: // left arm
        rectMode(CENTER);
        rect(this.x-25, this.y+175, 50, 6.5f);
        break;
        
      case 3: // right arm
        rectMode(CENTER);
        rect(this.x+25, this.y+175, 50, 6.5f);
        break;

      case 2: // left leg
        rectMode(CENTER);
        resetMatrix();
        rotate(radians(-45));
        translate(-300, 300);
        rect(this.x-36, this.y+176, 75, 6.5f);
        break;

      case 1: // right leg      
        resetMatrix();
        rotate(radians(45));
        translate(100, -300);
        rect(this.x-10, this.y+176, 75, 6.5f);      
        break;
      
    }
    
  }
  
  public void loseLife() {
    // draw person body part
    this.drawBodyPart();
    // lose life
    this.lives--; 
  }
  
  public void reset() {
    this.lives = 6;
  }
  
  // whether or not the person is dead
  public boolean isDead() {
     return (this.lives <= 0); 
  }

}
class Word {     

  String word;
  String[] words = {"computer", "language", "programming", "software", "keyboard", "mouse"};

  int x; // center x for word
  int y; // center y for word
  int c; // color
  int bc; // background cover
  
  int lineWidth;
  int spaceWidth;
  int wordWidth;
  int correct; // keep track of correct answers
  
  PFont txtFont;
  
  Word(int x, int y) {
    this.x = x;
    this.y = y;
    this.c = 0xffFFFFFF;
    this.correct = 0;
  }

  public void display() {
    this.pickRandomWord();
    this.drawLetterLines();
  }
    
  // pick a random letter to use for the game
  public void pickRandomWord() {
    int i = PApplet.parseInt(random(0, this.words.length));
    this.word = words[i];
  }
  
  // draw lines for word letters
  public void drawLetterLines() {
    // draw lines
    lineWidth = 30;
    spaceWidth = 10;
    wordWidth = (lineWidth * this.word.length()) + (spaceWidth * (this.word.length() - 1));
    int lx = this.x + (lineWidth/2) - (wordWidth/2);
    fill(this.c);
    rectMode(CENTER);
    for(int i = 0; i<this.word.length(); i++) {
        rect(lx, this.y, lineWidth, 2);
        lx += (lineWidth + spaceWidth);
    }
  }
  
  // check for letter in word
  public boolean hasLetter(char l) {
    boolean found = false;
    for(int i = 0; i<word.length(); i++) {
      if(word.charAt(i) == Character.toLowerCase(l)) {
        // found it
        found = true;
      }
    }
    return found;
  }
  
  // add letter for word
  public void addLetter(char l) {
    int lx = this.x + (lineWidth/2) - (wordWidth/2);
    for(int i = 0; i<word.length(); i++) {
      if(word.charAt(i) == Character.toLowerCase(l)) {
        // draw letter
        fill(this.c);
        textAlign(CENTER, CENTER);
        txtFont = createFont("Helvetica", 24);
        textFont(txtFont);
        text(l, lx, this.y-30);
        // count correct letters
        this.correct++;
      }
      lx += (lineWidth + spaceWidth);
    }
  }
  
  // if the word is complete or not
  public boolean isComplete() {
    return (this.correct >= this.word.length());
  }
  
}
  public void settings() {  size(850, 750); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "HangmanApp" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
